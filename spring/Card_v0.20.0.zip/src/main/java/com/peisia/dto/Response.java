
package com.peisia.dto;

public class Response {

    public Header header;
    public Body body;

}
