package com.peisia.service;

import java.util.ArrayList;

import com.peisia.dto.PjDto;

public interface PjService {
	public ArrayList<PjDto> getPjList();
	public ArrayList<PjDto> getGuildPjList();
	public void addPj(PjDto pj);
	public void updateGuild(int no);
}
