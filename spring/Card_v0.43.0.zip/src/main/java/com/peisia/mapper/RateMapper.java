package com.peisia.mapper;

import java.util.ArrayList;

import com.peisia.dto.rate.GradeDto;

public interface RateMapper {
    ArrayList<GradeDto> getRateGrade();
}
