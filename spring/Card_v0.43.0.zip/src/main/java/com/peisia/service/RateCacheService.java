package com.peisia.service;

import java.util.ArrayList;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Service;

import com.peisia.dto.rate.GradeDto;
import com.peisia.mapper.RateMapper;

@Service
public class RateCacheService implements InitializingBean {

    private final RateMapper gradeMapper;
    
    ////	확률들	////
    private ArrayList<GradeDto> rateGrade;

    public RateCacheService(RateMapper gradeMapper) {
        this.gradeMapper = gradeMapper;
    }

    /**
     * 이 메서드는 스프링이 RateCacheService 빈을 생성하고
     * 의존성 주입을 완료한 후 자동으로 실행됨.
     */
    @Override
    public void afterPropertiesSet() {
        rateGrade = gradeMapper.getRateGrade();
        System.out.println("등급 확률 캐싱 완료 (InitializingBean): " + rateGrade);
    }

    public ArrayList<GradeDto> getGradeChanceList() {
        return rateGrade;
    }
}
