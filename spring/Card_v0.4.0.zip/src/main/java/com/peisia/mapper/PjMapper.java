package com.peisia.mapper;

import java.util.ArrayList;

import com.peisia.dto.PjDto;

public interface PjMapper {
	public ArrayList<PjDto> getPjList();
}
