package com.peisia.dto;

import lombok.Data;

@Data
public class PjDto {
	private Long no;
	private String name;
	private String content;
	private String level;
	private Long gold;
}