package com.peisia.config;

public class Config {
	/** 
	 * 개발자 모드 
	 * 
	 * 이 설정을 true 로 하면
	 * 
	 * - 리액트에서 api 호출 시 세션 값을 무시하고 테스트 계정 (cat 회원)의 정보로 전송한다.
	 *  
	 * **/
	public static boolean DEVMODE = true; 
}
