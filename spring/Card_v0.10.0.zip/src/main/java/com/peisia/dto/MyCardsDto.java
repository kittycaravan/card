package com.peisia.dto;

import java.util.ArrayList;

public class MyCardsDto {
	public Integer pjId;
	public ArrayList<CardDto> cards = new ArrayList<CardDto>();
}