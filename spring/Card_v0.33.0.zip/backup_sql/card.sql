use my_cat;

show tables;

drop table card_my;
create table card_my(
	no int primary key auto_increment,
    job char(20) not null default '전사',
    grade char(20) not null default 'N',
    id char(20) not null default 'cat',
    deployment int not null default 0,
    lv int not null default 1,
    exp bigint unsigned not null default 0
);
ALTER TABLE card_my ADD lv int not null default 1;
ALTER TABLE card_my ADD exp bigint unsigned not null default 0;
select * from card_my;
select * from card_my where id='hellkitty';
select * from card_my where id='cat';
insert into card_my value();
update card_my set deployment = 1 where id = 'cat' and no = 1;
update card_my set deployment = 2 where id = 'cat' and no = 4;
update card_my set deployment = 3 where id = 'cat' and no = 2;
truncate card_my;

create table card_my_party(
	no int primary key auto_increment,
    job char(20) not null default '전사',
    grade char(20) not null default 'N',
    id char(20) not null default 'cat'
);
select * from card_my_party;
insert into card_my_party value();
delete from card_my_party;

truncate card_my_party;



##내 재산
drop table my_wealth;
create table my_wealth(
    gold int UNSIGNED not null default 0,
    dice int UNSIGNED not null default 0,
    id char(20) not null default 'cat'
);

select * from my_wealth;
insert into my_wealth value();
insert into my_wealth (id) value('dog');
update my_wealth set gold = -1 where id = 'cat';
update my_wealth set gold = 1 where id = 'cat';
update my_wealth set dice = -1 where id = 'cat';
update my_wealth set dice = 1 where id = 'cat';
update my_wealth set dice = 12 where id = 'cat';
truncate my_wealth;

#pj
truncate pj;
select * from pj;
create table pj(
	no	int primary key auto_increment		#번호
	,name char(40) not null default '무제'	#이름
	,content char(255) not null default '설명없음'		#설명
	,level	int not null default 1			#난이도
	,gold	bigint not null default 0	#보상(골드)    
    ,client char(40) not null default '제국'
    ,vendor char(40)
);
-- ALTER TABLE kitty ADD XXX int;-- 
ALTER TABLE pj ADD client char(40) not null default '제국';
ALTER TABLE pj ADD vendor char(40);
update pj set vendor = '고양이길드' where no=4;
insert into pj values();
insert into pj (name) values('약초캐기');
insert into pj (name) values('토끼사냥');
insert into pj (name) values('담배심부름');
select * from pj;
SELECT * from pj where vendor = '고양이길드';

-- 회원정보 테이블
create table card_member (
	id char(30) primary key,
    pw char(30) not null,
    guild_name char(20) default '고양이길드'
    );
ALTER TABLE card_member ADD guild_name char(20) default '고양이길드';    
insert into card_member values('cat','1234');
select * from card_member;

-- 레벨별 경험치표 테이블(card_exp_data.csv 파일로 데이터 넣었음)
create table card_exp (
	lv int primary key,
    required_exp bigint not null
);
select * from card_exp;


-- 트리거 --
-- 경험치가 추가되었을 때 경험치 테이블과 비교하여 필요경험치를 넘은 경우 레벨업 업데이트 시키는 트리거

DELIMITER $$
CREATE TRIGGER trg_update_level
AFTER UPDATE ON card_my
FOR EACH ROW
BEGIN
    DECLARE new_level INT;
    -- 현재 경험치보다 작거나 같은 최대 레벨 선택
    SELECT MAX(lv)
    INTO new_level
    FROM card_exp
    WHERE required_exp <= NEW.exp;

    -- 계산된 레벨을 NEW.lv에 반영
    SET NEW.lv = new_level;
END$$
DELIMITER ;
