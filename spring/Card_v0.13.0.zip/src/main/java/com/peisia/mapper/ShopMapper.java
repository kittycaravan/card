package com.peisia.mapper;

import com.peisia.dto.WealthDto;

public interface ShopMapper {
	public WealthDto getWealth();
	public void buyGold(long gold);
	public void buyDice();	
	public void payGold();
	public void payDice();
}
