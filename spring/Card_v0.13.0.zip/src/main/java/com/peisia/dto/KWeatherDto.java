
package com.peisia.dto;

public class KWeatherDto {

    public Response response;

}
