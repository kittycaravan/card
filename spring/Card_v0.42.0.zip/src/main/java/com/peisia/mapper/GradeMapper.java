package com.peisia.mapper;

import java.util.ArrayList;

import com.peisia.dto.GradeDto;

public interface GradeMapper {
    ArrayList<GradeDto> selectGradeChances();
}
