use my_card;

## 8. 카드 - 직업표 (확률 포함) 확률값은 10000 을 100% 로 둔 정수값으로 함.
select * from card_job_table;
select * from card_job_table order by chance;
drop table card_job_table;
CREATE TABLE card_job_table (
  job_name VARCHAR(30) PRIMARY KEY,
  job_kor_name VARCHAR(30) not null unique,
  chance int not null
);
-- todo: 아래 데이터도 넣어야함. 고정.
INSERT INTO card_job_table (job_name, job_kor_name, chance) VALUES
('warrior', '전사', 2000),
('ice_mage', '얼음마법사', 2000),
('elf_archer', '엘프궁수', 2000),
('rogue', '도적', 2000),
('cleric', '사제', 2000);

