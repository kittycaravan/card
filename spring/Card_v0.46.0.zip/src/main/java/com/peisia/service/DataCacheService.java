package com.peisia.service;

import java.util.ArrayList;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Service;

import com.peisia.dto.game.DataJobDto;
import com.peisia.dto.rate.GradeDto;
import com.peisia.mapper.DataCacheMapper;

import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class DataCacheService implements InitializingBean {

    private final DataCacheMapper dataCacheMapper;
    
    ////	캐시 데이터들	////
    private ArrayList<GradeDto> rateGrade;
    private ArrayList<DataJobDto> dataJob;

    public DataCacheService(DataCacheMapper gradeMapper) {
        this.dataCacheMapper = gradeMapper;
    }

    /**
     * 이 메서드는 스프링이 RateCacheService 빈을 생성하고
     * 의존성 주입을 완료한 후 자동으로 실행됨.
     */
    @Override
    public void afterPropertiesSet() {
        rateGrade = dataCacheMapper.getRateGrade();
        log.info("==== 데이터 캐싱 완료 - 등급(확률) 데이터: " + rateGrade);
        dataJob = dataCacheMapper.getDataJob();
        log.info("==== 데이터 캐싱 완료 - 직업 데이터: " + dataJob);
    }

    public ArrayList<GradeDto> getRateGrade() {
        return rateGrade;
    }
    
    public ArrayList<DataJobDto> getDataJob() {
    	return dataJob;
    }
}
