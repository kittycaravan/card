package com.peisia.dto.game;

import lombok.Data;

@Data
public class DataJobDto {
    private String job_name;
    private String job_kor_name;
    private int chance;
}