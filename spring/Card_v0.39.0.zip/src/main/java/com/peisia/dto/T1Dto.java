package com.peisia.dto;

import lombok.Data;

@Data
public class T1Dto {
	private String cat;
	private String dog;
}