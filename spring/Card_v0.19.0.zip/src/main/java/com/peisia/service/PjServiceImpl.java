package com.peisia.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.peisia.dto.CardDto;
import com.peisia.dto.MyCardsDto;
import com.peisia.dto.PjDto;
import com.peisia.mapper.CardMapper;
import com.peisia.mapper.PjMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
//@AllArgsConstructor
public class PjServiceImpl implements PjService{

	@Setter(onMethod_ = @Autowired)
	private PjMapper mapper;
	@Setter(onMethod_ = @Autowired)
	private CardMapper cardMapper;

	@Override
	public ArrayList<PjDto> getPjList() {
		ArrayList<PjDto> pjs = mapper.getPjList();
		return pjs;
	}
	@Override
	public ArrayList<PjDto> getGuildPjList() {
		ArrayList<PjDto> pjs = mapper.getGuildPjList();
		
		//카드들을 파견지별로 나눠서 파견지 pjId 를 키로 밸류에 카드배열을 넣어 리턴
		//문제발생: hash 구조를 써먹지 못함 그래서 일반 배열 중첩으로 변경하겠음
		ArrayList<CardDto> cards = cardMapper.getMyCards();	//모든 카드를 다 가져오고
		for(CardDto c : cards) {
			for(PjDto m: pjs) {	//기존 pjs 배열 탐색
				if(m.getNo() == c.getDeployment()) {	//pjId 를 검사해서
					m.cards.add(c);	// 찾으면 해당 pj 안에 add
					break;
				}
			}
		}		
		return pjs;
	}

	@Override
	public void addPj(PjDto pj) {
		mapper.addPj(pj);
	}
}