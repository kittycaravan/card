package com.peisia.service;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.peisia.c.util.Dice;
import com.peisia.dto.CardDto;
import com.peisia.dto.MyCardsDto;
import com.peisia.dto.SelectCardDto;
import com.peisia.mapper.CardMapper;
import com.peisia.mapper.ShopMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
//@AllArgsConstructor
public class CardServiceImpl implements CardService{

	@Setter(onMethod_ = @Autowired)
	private CardMapper mapper;
	@Setter(onMethod_ = @Autowired)
	private ShopMapper mapperShop;

	@Override
	public ArrayList<CardDto> getList(String id) {
		ArrayList<CardDto> n = mapper.getList(id);
		return n;
	}

	//todo
	//확인중
	//미사용 함수
//	@Transactional	//트랜잭션 처리함
//	@Override
//	public void addCard(CardDto c) {
//		mapper.addCard(c);
//		mapperShop.payDice();	//다이스박스 차감 까지해야함
//	}

	@Override
	public void pjMemberAdd(SelectCardDto c) {
		mapper.pjMemberAdd(c);
	}

	@Override
	public ArrayList<CardDto> getPjMember(int no) {
		ArrayList<CardDto> n = mapper.getPjMember(no);
		return n;		
	}	
	@Override
	public void clearPjMember(long pjId) {
		mapper.clearPjMember(pjId);
	}

	@Transactional
	@Override
	public ArrayList<CardDto> gacha(String id) {
		String jobs[] = {"전사","마법사","궁수","도적","사제"};
		String grade[] = {"SSR","SR","S","R","H","N"};
		CardDto c = new CardDto(jobs[Dice.roll(0,4)],grade[getLuck()]);		
		mapper.addCard(c,id);
		mapperShop.payDice();	//다이스박스 차감 까지해야함
		return getList(id);	//가챠로 뽑은 카드가 추가된 최종 목록을 다시 가져와서 api로 뿌려줌
	}
	
	public int getLuck() {
		//확률 공개:
		//SSR: 1%
		//SR: 3%
		//S: 6%
		//R: 10%
		//H: 30%
		//N: 50%
		int r = Dice.roll(1,100);
		int t = 5;	// N Normal
		if(r<=50) {	// H High
			t = 4; 
		}
		if(r<=20) {	// R Rare
			t = 3; 
		}
		if(r<=10) {	// S Super
			t = 2; 
		}
		if(r<=4) {	// SR SuperRare
			t = 1; 
		}
		if(r==1) {	// SSR SuperSuperRare
			t = 0; 
		}
		return t;
	}	
}