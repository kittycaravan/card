package com.peisia.dto;

import lombok.Data;

@Data
public class WealthDto {
	private String gold;
	private String dice;
	private String id;
}