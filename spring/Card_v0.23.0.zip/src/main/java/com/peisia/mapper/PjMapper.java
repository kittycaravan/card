package com.peisia.mapper;

import java.util.ArrayList;

import com.peisia.dto.PjDto;

public interface PjMapper {
	public ArrayList<PjDto> getGuildPjList();
	public ArrayList<PjDto> getPjList();
	public void addPj(PjDto pj);
	public void updateGuild(int no);
	public void delPj(int no);
}
