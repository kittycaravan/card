package com.peisia.service;

import java.util.ArrayList;

import com.peisia.dto.PjDto;

public interface PjService {
	public ArrayList<PjDto> getPjList();
}
