import React, { useState } from 'react';
import './Sea.css'
function Sea() {
  return(
    <div id='game_sea_bg' style={{backgroundImage: 'url(/card/resources/img/bg/bg_sea.webp)'}}>
      <h1>Sea</h1>
    </div>
  );
}
export default Sea;