import React, { useState } from 'react';
import './Cinematic.css';
function Cinematic() {
  return(
    <div id='system_cinematic_bg' style={{backgroundImage: 'url(/card/resources/img/bg/bg_cinematic.jpg)'}}>
      <h1>Cinematic</h1>
    </div>
  );
}
export default Cinematic;