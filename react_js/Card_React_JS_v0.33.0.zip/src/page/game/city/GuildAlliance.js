import axios from 'axios';
import React, { useState, useEffect } from 'react';
import './GuildAlliance.css';
import API from '../../../API.js';
import Stars from '../Stars.js';
function GuildAllience() {
  var [pjList,setPjList] = useState([]);

  var [name,setName] = useState('');
  var [content,setContent] = useState('');
  var [level,setLevel] = useState('');
  var [gold,setGold] = useState('');

  useEffect(() => {	
    commonGetApi(API.GET_PJ_LIST,setPjList);
    return () => {
    };
  }, []); // []로 비우기	   
  function commonGetApi(url,setter){
    axios.get(url)			
    .then(response => setter(response.data) )		
    .catch(error => console.error('에러:', error) );
  }
  function xxx(){
    var d = {
      name : name,
      content : content,
      level : level,
      gold : gold
    };

    //api 전송
    axios.post(API.ADD_PJ,d)			
      .then(()=>{
          commonGetApi(API.GET_PJ_LIST,setPjList);  //등록 후 화면 갱신 되도록 받아오기
          // 다 비우기
          setName('');
          setContent('');
          setLevel('');
          setGold('');
        }
      )		
      .catch(error => console.error('에러:', error) );    
  }  
  function updateGuild(no){
    axios.post(API.UPDATE_GUILD+'?no='+no)			
      .then(()=>{
        commonGetApi(API.GET_PJ_LIST,setPjList);  //신청 후 화면 갱신 되도록 받아오기        
      })
      .catch(error => console.error('에러:', error) );        
  }

  return(
    <div id='game_city_guild_alliance_bg' style={{backgroundImage: 'url(/card/resources/img/bg/bg_guild_alliance.webp)'}}>
      <fieldset id='game_city_guild_alliance_pj_add_bg'>
        <legend>프로젝트 추가</legend>
        <div id='pj_add'>
          <input className='pj_input' placeholder='이름' onChange={(e)=>setName(e.target.value)} value={name}></input>&nbsp;&nbsp;
          <input className='pj_input' placeholder='내용' onChange={(e)=>setContent(e.target.value)} value={content}></input>&nbsp;&nbsp;
          <input className='pj_input' placeholder='레벨' onChange={(e)=>setLevel(e.target.value)} value={level}></input>&nbsp;&nbsp;
          <input className='pj_input' placeholder='보상' onChange={(e)=>setGold(e.target.value)} value={gold}></input>&nbsp;&nbsp;
          <button id='pj_add_btn' onClick={xxx} style={{backgroundImage: 'url(/card/resources/img/bg/board_bg.webp)'}}>프로젝트<br></br>등록</button>
        </div>
        
      </fieldset>
      <fieldset id='game_city_guild_alliance_board_bg' style={{backgroundImage: 'url(/card/resources/img/bg/board_bg.webp)'}}>
        <legend>프로젝트 공고</legend>
        <table id='pj_list_table'>
          <tr className='pj_list_tr'>
            <td className='pj_list_td pj_list_no'>no.</td>
            <td className='pj_list_td pj_list_name'>이름</td>
            <td className='pj_list_td pj_list_content'>내용</td>
            <td className='pj_list_td pj_list_level'>난이도</td>
            <td className='pj_list_td pj_list_gold'>보상</td>
            <td className='pj_list_td pj_list_client'>발주처</td>
            <td className='pj_list_td pj_list_vendor'>외주길드</td>
          </tr>
          {
            pjList.map((d,i)=> <tr className='pj_list_tr' key={i}>
                
            <td className='pj_list_td pj_list_no'>{d.no}</td>
            <td className='pj_list_td pj_list_name'>{d.name}</td>
            <td className='pj_list_td pj_list_content pj_list_td_align_left'>&nbsp;{d.content}</td>
            <td className='pj_list_td pj_list_level pj_list_td_align_left'><Stars amount={d.level} /></td>
            <td className='pj_list_td pj_list_gold'>{d.gold}💰</td>            
            <td className='pj_list_td pj_list_client'>{d.client}</td>            
            <td className='pj_list_td pj_list_vendor'>
              {d.vendor ? d.vendor :<button onClick={()=>updateGuild(d.no)}>신청하기</button>}
            </td>            
          </tr>)
          } 
        </table>
      </fieldset>
    </div>
  )

}
export default GuildAllience;