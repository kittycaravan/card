const BASE_URL = "http://localhost:8080/card";

const API = {
    GET_PJ_LIST : `${BASE_URL}/pj/getPjList`
    ,GET_GUILD_PJ_LIST : `${BASE_URL}/pj/getGuildPjList`
    ,GACHA : `${BASE_URL}/cards/gacha`
    ,CLEAR_PJ_MEMBER : `${BASE_URL}/cards/clearPjMember`
    ,GET_MY_CARDS : `${BASE_URL}/cards/getMyCards`
    ,GET_PJ_MEMBER : `${BASE_URL}/cards/getPjMember?no=1`
    ,GET_WEALTH : `${BASE_URL}/shop/getWealth`
    ,BUY_GOLD : `${BASE_URL}/shop/buyGold`
    ,BUY_DICE : `${BASE_URL}/shop/buyDice`
    ,PJ_MEMBER_ADD : `${BASE_URL}/cards/pjMemberAdd`
    ,SELL_CARD : `${BASE_URL}/shop/sellCard`
    ,ADD_PJ : `${BASE_URL}/pj/addPj`
    ,UPDATE_GUILD : `${BASE_URL}/pj/updateGuild`
    ,PROC_PJ : `${BASE_URL}/pj/procPj`
    ,LOGIN : `${BASE_URL}/member/login`
    ,REG : `${BASE_URL}/member/reg`
};

// export const GET_PJ_LIST = `${BASE_URL}/pj/getPjList`;
export default API;
