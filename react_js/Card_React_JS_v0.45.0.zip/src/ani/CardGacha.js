import { useRef, useState, useEffect } from 'react';
import './CardGacha.css';

export default function CardGacha({ xxx }) {
  // useRef: DOM 요소에 직접 접근하거나, 변경 가능한 값을 저장할 수 있는 훅
  // 초기값은 null로 설정하며, videoRef.current를 통해 해당 DOM 요소에 접근할 수 있음
  // useRef는 리렌더링 시에도 참조 값을 유지하지만, 값이 바뀌어도 리렌더링을 트리거하지 않음
  const videoRef = useRef(null);

  // 컴포넌트가 표시 중인지 여부를 제어하는 상태 (초기에는 true)
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    // 비디오 재생이 끝났을 때 실행될 콜백 함수
    const handleEnded = () => {
      xxx({ visible: false }); // 부모 컴포넌트에 알림
      setVisible(false); // 이 컴포넌트 자체를 숨김
      console.log('가챠 애니메이션 종료');
    };

    // useRef로 참조된 비디오 DOM 요소 가져오기
    const video = videoRef.current;

    // 비디오가 존재할 경우, 'ended' 이벤트 리스너 등록
    if (video) {
      video.addEventListener('ended', handleEnded);

      // 컴포넌트가 언마운트되거나 useEffect가 다시 실행될 경우 리스너 제거
      return () => {
        video.removeEventListener('ended', handleEnded);
      };
    }
  }, []); // 빈 배열은 컴포넌트 마운트 시 한 번만 실행됨

  // visible 상태가 false면 아무것도 렌더링하지 않음 (컴포넌트가 사라짐)
  if (!visible) return null;

  return (
    <video
      id='card_gacha_video'            // CSS에서 사용될 ID
      ref={videoRef}                   // 이 ref를 통해 해당 DOM 요소에 접근 가능
      src="/card/resources/ani/상자.mp4" // 비디오 파일 경로
      autoPlay                         // 컴포넌트 로딩 후 자동으로 재생
      playsInline                      // 모바일에서 전체화면 대신 인라인 재생 허용
      muted                            // 자동 재생을 위해 음소거 (브라우저 정책 우회)
      className="w-full h-auto"        // Tailwind로 크기 조절
    />
  );
}