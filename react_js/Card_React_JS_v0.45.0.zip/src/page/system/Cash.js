import React, { useState } from 'react';
import './Cash.css';
function Cash() {
  return(
    <div id='system_cash_bg' style={{backgroundImage: 'url(/card/resources/img/bg/bg_cash.webp)'}}>
      <h1>캐쉬 상점</h1>
    </div>
  );
}
export default Cash;