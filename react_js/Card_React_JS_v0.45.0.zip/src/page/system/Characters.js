import React, { useState } from 'react';
import './Characters.css';
function Characters() {
  return(
    <div id='system_characters_bg' style={{backgroundImage: 'url(/card/resources/img/bg/bg_characters.webp)'}}>
      <h1>케릭터 관리</h1>
    </div>
  );
}
export default Characters;