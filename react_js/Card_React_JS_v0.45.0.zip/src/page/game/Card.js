import '../../App.css';
import './Card.css';
function Card({ job, grade, lv, type, xxx}) {
  return (
    <div className={`card ${grade}`} onClick={xxx} 
      style={{backgroundImage: `url(/card/resources/img/cards/job/${job}/${job}_${grade}0${type}_256_q85.jpg)`}}>
      <div className='card_top_translucent_bg'>
        {/* <div className='card_grade'>{grade}</div> */}
        <div className='card_job'>{job}</div>
      </div>
      <div className='card_bot_translucent_bg'>
        <div className='card_lv'>Lv {lv}</div>
      </div>
    </div>
  );
}

export default Card;