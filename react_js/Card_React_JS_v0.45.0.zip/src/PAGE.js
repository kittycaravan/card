const PAGE = {
    LOGIN : 'login'
    ,REG : 'reg'
    ,SYSTEM : 'system'
    ,SYSTEM_LOBBY : 'system_lobby'
    ,SYSTEM_CASH : 'system_cash'
    ,SYSTEM_CHARACTERS : 'system_characters'
    ,SYSTEM_COMMUNITY : 'system_community'
    
    ,GAME : 'game'
    ,GAME_MAP : 'game_map'
    // ,GAME_MAP_WORLD : 'game_map_world'
    // ,GAME_MAP_CONTINENT : 'game_map_continent'
    ,GAME_SEA : 'game_sea'
    ,GAME_LAND : 'game_land'
    ,GAME_CITY : 'game_city'
    ,GAME_CITY_GUILD : 'game_city_guild'
    ,GAME_CITY_GUILD_ALLIANCE : 'game_city_guild_alliance'
    ,GAME_CINEMATIC : 'game_cinematic'
};

export default PAGE;