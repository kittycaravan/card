import React, { useState } from 'react';

import PAGE from '../../PAGE.js';

import Guild from './city/Guild.js';
import GuildAlliance from './city/GuildAlliance.js';

function City() {
  var [currentPage,setCurrentPage] = useState(PAGE.GAME_CITY_GUILD);

  const game_city_guild = () => setCurrentPage(PAGE.GAME_CITY_GUILD);
  const game_city_guild_alliance = () => setCurrentPage(PAGE.GAME_CITY_GUILD_ALLIANCE);

  return(
    <>
      <nav>
        <button onClick={game_city_guild}>내 길드</button>
        <button onClick={game_city_guild_alliance}>길드 연합회</button>
      </nav>    
      {currentPage === PAGE.GAME_CITY_GUILD && <Guild/>}
      {currentPage === PAGE.GAME_CITY_GUILD_ALLIANCE && <GuildAlliance/>}
    </>
  );
}
export default City;