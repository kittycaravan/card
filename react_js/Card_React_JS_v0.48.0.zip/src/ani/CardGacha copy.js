import { useRef, useState, useEffect } from 'react';
import './CardGacha.css';

export default function CardGacha({xxx}){
  const videoRef = useRef(null);
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const handleEnded = () => {
        xxx({ visible: false });
        setVisible(false);
        console.log('가챠 애니메이션 종료');
    }
    const video = videoRef.current;

    if (video) {
      video.addEventListener('ended', handleEnded);
      return () => {
        video.removeEventListener('ended', handleEnded);
      };
    }
  }, []);

  if (!visible) return null;

  return (
    <video id='card_gacha_video'
      ref={videoRef}
      src="/card/resources/ani/상자.mp4"
      autoPlay
      playsInline
      muted
      className="w-full h-auto"
    />
  );
}