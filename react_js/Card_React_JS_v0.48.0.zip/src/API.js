const BASE_URL = "http://localhost:8080/card";

const API = {
    GACHA : `${BASE_URL}/cards/gacha`
    ,GACHA10 : `${BASE_URL}/cards/gacha10`
    ,CLEAR_PJ_MEMBER : `${BASE_URL}/cards/clearPjMember`
    ,GET_MY_CARDS : `${BASE_URL}/cards/getMyCards`
    ,GET_PJ_MEMBER : `${BASE_URL}/cards/getPjMember?no=1`

    ,GET_PJ_LIST : `${BASE_URL}/pj/getPjList`
    ,GET_GUILD_PJ_LIST : `${BASE_URL}/pj/getGuildPjList`
    ,UPDATE_GUILD : `${BASE_URL}/pj/updateGuild`
    ,PROC_PJ : `${BASE_URL}/pj/procPj`
    ,ADD_PJ : `${BASE_URL}/pj/addPj`
    
    ,GET_WEALTH : `${BASE_URL}/shop/getWealth`
    ,BUY_GOLD : `${BASE_URL}/shop/buyGold`
    ,BUY_DICE : `${BASE_URL}/shop/buyDice`
    ,PJ_MEMBER_ADD : `${BASE_URL}/cards/pjMemberAdd`
    ,SELL_CARD : `${BASE_URL}/shop/sellCard`
    
    ,LOGIN : `${BASE_URL}/member/login`
    ,REG : `${BASE_URL}/member/reg`
    ,LOGOUT : `${BASE_URL}/member/logout`
};

// export const GET_PJ_LIST = `${BASE_URL}/pj/getPjList`;
export default API;
