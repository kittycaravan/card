import React, { useState } from 'react';
import "./Land.css"
function Land() {
  return(
    <div id='game_land_bg' style={{backgroundImage: 'url(/card/resources/img/bg/bg_land.webp)'}}>
      <h1>Land</h1>
    </div>
  );
}
export default Land;