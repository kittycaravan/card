import React, { useState } from 'react';
import './Community.css';
function Community() {
  return(
    <div id='system_community_bg' style={{backgroundImage: 'url(/card/resources/img/bg/bg_community.webp)'}}>
      <h1>커뮤니티</h1>
    </div>
  );
}
export default Community;