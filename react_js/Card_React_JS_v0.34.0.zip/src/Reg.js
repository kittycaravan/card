import React, { useState } from 'react';
import axios from 'axios'; // axios를 별도로 임포트
import './Reg.css';
import PAGE from './PAGE.js';
import API from './API.js';

export default function Reg({ changeRootPage }) {
  var [id, setId] = useState('');
  var [password, setPassword] = useState('');
  var [guildName, setGuildName] = useState('');

  return (
    <div id='loginbox' style={{ backgroundImage: 'url(/card/resources/img/bg/login.png)', backgroundSize: 'cover', height: '100vh' }}>
      <form id="loginForm" onSubmit={(e) => {
        e.preventDefault();
        console.log("회원가입 시도");
        // axios 통신. 데이터 키, 값 주의.
        const d = {
          id: id,
          pw: password,
          guildName: guildName
        }
        axios.post(API.REG, d)
          .then(response => {
            if (response.data.success) {
              alert('회원 가입되었습니다.');
            } else {
              alert('회원가입에 실패 하였습니다. : ');
            }
            changeRootPage(PAGE.LOGIN);
          })
          .catch(error => {
            console.error('회원가입 오류:', error);
            alert('회원가입 중 오류 발생');
          });
      }}>
        <br></br>
        <p>회원가입</p>
        <br></br>
        <input type="text" placeholder="아이디" onChange={(e) => setId(e.target.value)} />
        <br></br>
        <input type="password" placeholder="비밀번호" onChange={(e) => setPassword(e.target.value)} />
        <br></br>
        <input placeholder="길드 이름을 정해주세요" onChange={(e) => setGuildName(e.target.value)} />
        <br></br>
        <button type="submit">회원가입</button>
        <br></br>
        <button type="reset" onClick={() => changeRootPage(PAGE.LOGIN)}>취소</button>
        <br></br>
      </form>
    </div>
  );
}