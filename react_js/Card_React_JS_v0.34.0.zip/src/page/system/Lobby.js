import React, { useState } from 'react';
import './Lobby.css';
function Lobby() {
  return(
    <div id='system_lobby_bg' style={{backgroundImage: 'url(/card/resources/img/bg/bg_lobby.webp)'}}>
      <h1>로비</h1>
    </div>
  );
}
export default Lobby;