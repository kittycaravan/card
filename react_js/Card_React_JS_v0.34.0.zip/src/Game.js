import PAGE from './PAGE.js';
import React, { useState, useEffect } from 'react';
import './Game.css';
import CountDownTimer from './CountDownTimer.js';
import Cinematic from './page/game/Cinematic.js';
import Land from './page/game/Land.js';
import Map from './page/game/Map.js';
import City from './page/game/City.js';
import Sea from './page/game/Sea.js';
function Game({changeRootPage}) {
  var [currentPage,setCurrentPage] = useState(PAGE.GAME_CITY);
  return(
    <>
      {/* 페이지 전환 버튼 */}
      <nav>
        <button onClick={() => setCurrentPage(PAGE.GAME_CINEMATIC)}>시네마틱</button>
        <button onClick={() => setCurrentPage(PAGE.GAME_LAND)}>땅</button>
        <button onClick={() => setCurrentPage(PAGE.GAME_MAP)}>맵</button>
        <button onClick={() => setCurrentPage(PAGE.GAME_CITY)}>도시</button>
        <button onClick={() => setCurrentPage(PAGE.GAME_SEA)}>바다</button>&nbsp;
        <button onClick={()=>changeRootPage(PAGE.SYSTEM)}>시스템 메뉴로</button>
        <CountDownTimer title='다이스 자동 충전:' startSec={300} />
      </nav>    
      {currentPage === PAGE.GAME_CINEMATIC && <Cinematic/>}
      {currentPage === PAGE.GAME_LAND && <Land/>}
      {currentPage === PAGE.GAME_MAP && <Map/>}
      {currentPage === PAGE.GAME_CITY && <City/>}
      {currentPage === PAGE.GAME_SEA && <Sea/>}
    </>
  );
}
export default Game;