import React from 'react';
import './cardpopup.css';

function CardPopup({ x, y, pjList, card, onClose, onSell }) {
  return (
    <div
      className="popup-menu"
      style={{
        top: y,
        left: x,
      }}
    >
      <p>직업: {card.job}</p>
      <p>등급: {card.grade}</p>
      <button onClick={() => alert('상세 보기 클릭')}>카드 상세보기</button>
      {/* pjList.map을 사용하여 pjList의 각 항목을 <option>으로 렌더링. */}
      {/* <select onChange={(e)=> alert(e.target.value)}> */}
      <select onChange={(e)=>onClose(card.no, e.target.value)}>
        <option key='0' value='0'>대기</option>
        {pjList.map((pj) => (
          <option key={pj.no} value={pj.no}>
            {pj.no} - {pj.name}
          </option>
        ))}
      </select>
      <button onClick={(e)=>{
          onSell(card.no);
          onClose(0,0);
        }
        }>이적</button>
      <button onClick={(e)=>onClose(0,0)}>닫기</button>
    </div>
  );
}

export default CardPopup;
