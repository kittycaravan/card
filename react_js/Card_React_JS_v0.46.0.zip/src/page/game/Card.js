import '../../App.css';
import './Card.css';
// function Card({ job, grade, lv, type, xxx}) {
function Card({ card, xxx}) {
  return (
    <div className={`card ${card.grade}`} onClick={xxx} 
      style={{backgroundImage: `url(/card/resources/img/cards/job/${card.job}/${card.job}_${card.grade}0${card.type}_256_q85.jpg)`}}>
      <div className='card_top_translucent_bg'>
        {/* <div className='card_grade'>{grade}</div> */}
        <div className='card_job'>{card.job_kor_name}</div>
      </div>
      <div className='card_bot_translucent_bg'>
        <div className='card_lv'>Lv {card.lv}</div>
      </div>
    </div>
  );
}

export default Card;