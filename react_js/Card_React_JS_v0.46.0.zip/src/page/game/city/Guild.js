import axios from 'axios';
import React, { useState, useEffect } from 'react';
import './Guild.css';

import API from '../../../API.js';
// import Clock from './Clock.js';
import Card from '../Card.js';
import PjTag from '../PjTag.js';
import CardPopup from '../CardPopup.js';
import CardGacha from '../../../ani/CardGacha.js';

function GuildHome() {
  var [wealth,setWealth] = useState({dice:0,gold:0});
  var [my,setMy] = useState([]);
  var [pjList,setPjList] = useState([]);
  var [popup, setPopup] = useState({ visible: false, x: 0, y: 0, card: null });
  var [cardGachaAni, setCardGachaAni] = useState({ visible: false });
  useEffect(() => {	
    commonGetApi(API.GET_WEALTH,setWealth);
    commonGetApi(API.GET_MY_CARDS,setMy);
    commonGetApi(API.GET_GUILD_PJ_LIST,setPjList);
    return () => {
    };
  }, []); // []로 비우기	 
  function commonGetApi(url,setter){
    axios.get(url)			
    .then(response => setter(response.data) )		
    .catch(error => console.error('에러:', error) );
  }
  function pjMemberAdd(d){
    axios.post(API.PJ_MEMBER_ADD,d)			
    .then(() => {
      commonGetApi(API.GET_MY_CARDS,setMy);
      commonGetApi(API.GET_GUILD_PJ_LIST,setPjList);		
    })		
    .catch(error => console.error('에러:', error) );
  }
  function gachaApi(){
    axios.get(API.GACHA)			
    .then(response => {
      setMy(response.data);
      commonGetApi(API.GET_WEALTH,setWealth);
      setCardGachaAni({ visible: true });
    })		
    .catch(error => console.error('에러:', error) );    
  }
  function clearPjApi(pjId){
    axios.get(API.CLEAR_PJ_MEMBER+'?pjId='+pjId)
    .then(() => {		
      commonGetApi(API.GET_MY_CARDS,setMy);
      commonGetApi(API.GET_GUILD_PJ_LIST,setPjList);
    })		
    .catch(error => console.error('에러:', error) );
  }
  function buyGold(){
    axios.get(API.BUY_GOLD)			
    .then(() => commonGetApi(API.GET_WEALTH,setWealth) )		
    .catch(error => console.error('에러:', error) );
  }
  function buyDice(){
    axios.get(API.BUY_DICE)			
    .then(() => commonGetApi(API.GET_WEALTH,setWealth) )		    
    .catch(error => console.error('에러:', error) );
  }  
  function sellCard(cardNo){
    axios.get(API.SELL_CARD+"?no="+cardNo)			
    .then(() => {		
      commonGetApi(API.GET_MY_CARDS,setMy);
      commonGetApi(API.GET_WEALTH,setWealth);
    })		
    .catch(error => console.error('에러:', error) );
  }  
  function handleCardClick(e, card) {
    const rect = e.target.getBoundingClientRect(); // 클릭한 컴포넌트의 좌표 객체를 얻는 함수. x,y 는좌상단. width,height 있음. top/right/bottom/left 있음
    setPopup({visible: true, x: rect.right + window.scrollX, 
      y: rect.top + window.scrollY, card: card,}); // 스크롤 된 경우 스크롤 좌표 값까지 추가
  }
  function closePopup(cardNo, selectPjId) { //card 고유값과, 파견지 pjId
    if(cardNo>0, selectPjId>0){
      var d = {id:'cat',no: cardNo,pjId: selectPjId};
      pjMemberAdd(d);
    }
    setPopup({ visible: false, x: 0, y: 0, card: null });
  }
  return (
    <div id="game_city_guild_bg" style={{backgroundImage: 'url(/card/resources/img/bg/bg_guild.webp)'}}>
      {/* <Clock /> */}
      {pjList.map((d,i)=> <PjTag key={i} pjData={d} clearPjListener={clearPjApi} setPjList={setPjList} setWealth={setWealth} setMy={setMy}/>)}
      <div id='card_area'>
        {my.map((character, index) => (
          // 카드 컴포넌트가 사용되는 곳 [1/2] (나머진 PjTag.js임.)
          // <Card key={index} job={character.job} grade={character.grade} lv={character.lv} type={character.type} xxx={(e) => handleCardClick(e, character)} />
          <Card key={index} card={character} xxx={(e) => handleCardClick(e, character)} />
        ))}
      </div>
      <fieldset id="guild_fieldset_shop">
        <legend>&nbsp;상점&nbsp;</legend>
        <span>{wealth.dice}🎲 {wealth.gold}💰</span>&nbsp;&nbsp;
        <button onClick={buyDice}>주사위상자 구매</button>&nbsp;&nbsp;
        <button onClick={buyGold}>골드 충전(9만원)</button>&nbsp;&nbsp;
        <button onClick={gachaApi}>카드 1뽑 가챠</button>
      </fieldset>
      {popup.visible && (
        <CardPopup x={popup.x} y={popup.y} pjList={pjList}
          card={popup.card} onSell={sellCard} onClose={closePopup} />
      )}
      {cardGachaAni.visible && <CardGacha xxx={setCardGachaAni}/> }
    </div>
  );
}
export default GuildHome;