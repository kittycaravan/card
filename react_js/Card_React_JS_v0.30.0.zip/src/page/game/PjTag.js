import '../../App.css';
import Stars from './Stars.js';
import Card from './Card.js';
import axios from 'axios';
import API from '../../API.js';

function PjTag({ pjData, clearPjListener, setPjList, setWealth, setMy }) {
  function commonGetApi(url,setter){
    axios.get(url)			
    .then(response => setter(response.data) )		
    .catch(error => console.error('에러:', error) );
  }  
  function kickOff(no){
    alert(`프로젝트 ${no} 시작`);

    axios.get(API.PROC_PJ+'?no='+no)
      .then(response=>{
        commonGetApi(API.GET_GUILD_PJ_LIST,setPjList);
        commonGetApi(API.GET_WEALTH,setWealth);
        commonGetApi(API.GET_MY_CARDS,setMy);
        if(response.data.success) {
          alert('프로젝트가 성공적으로 끝났습니다.');
        } else {
          alert('프로젝트가 실패했습니다.');
        }
      })
      .catch(error=>console.log(`error : ${error}`));

  }

  return (
    <>
      <fieldset>
        <legend>
          {pjData.no} {pjData.name} <Stars amount={pjData.level} /> {pjData.gold}💰 {pjData.content}
          &nbsp;&nbsp;<button onClick={()=>clearPjListener(pjData.no)}>참여인원 비우기</button>
          &nbsp;&nbsp;<button onClick={()=>kickOff(pjData.no)}>프로젝트 시작(킥오프)</button>
        </legend>
        <div id='card_area'>
          {pjData.cards.map((card,i)=>
            <Card key={i} job={card.job} grade={card.grade} />
          )}
        </div>
      </fieldset>    
    </>
  );
}

export default PjTag;