import axios from 'axios';
import PAGE from './PAGE.js';
import API from './API.js';
import React, { useState, useEffect } from 'react';
import './System.css';
import Lobby from './page/system/Lobby.js';
import Cash from './page/system/Cash.js';
import Characters from './page/system/Characters.js';
import Community from './page/system/Community.js';
function System({ changeRootPage }) {
  var [currentPage, setCurrentPage] = useState(PAGE.SYSTEM_LOBBY);
  return (
    <>
      {/* 페이지 전환 버튼 */}
      <nav>
        <button onClick={() => setCurrentPage(PAGE.SYSTEM_LOBBY)}>로비</button>
        <button onClick={() => setCurrentPage(PAGE.SYSTEM_CASH)}>캐쉬 상점</button>
        <button onClick={() => setCurrentPage(PAGE.SYSTEM_CHARACTERS)}>케릭터 관리</button>
        <button onClick={() => setCurrentPage(PAGE.SYSTEM_COMMUNITY)}>커뮤니티</button>&nbsp;
        <button onClick={() => changeRootPage(PAGE.GAME)}>게임시작</button>
        {/* 로그아웃 처리 */}
        <button onClick={() => {
          axios.get(API.LOGOUT)
            .then(response => {
              if(response.data.success) {
                console.log('로그아웃 되었습니다.');
                changeRootPage(PAGE.LOGIN); // 로그인 페이지로 이동
              }
            })
            .catch(error => console.error('에러:', error));
        }}>로그아웃</button>
      </nav>
      {currentPage === PAGE.SYSTEM_LOBBY && <Lobby />}
      {currentPage === PAGE.SYSTEM_CASH && <Cash />}
      {currentPage === PAGE.SYSTEM_CHARACTERS && <Characters />}
      {currentPage === PAGE.SYSTEM_COMMUNITY && <Community />}
    </>
  );
}
export default System;