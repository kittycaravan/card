import React, { useState } from 'react';
import './App.css';
import PAGE from './PAGE.js';
import System from './System.js';
import Game from './Game.js';
import Login from './Login.js';
import Reg from './Reg.js';

function App() {
  // var [currentPage,setCurrentPage] = useState(PAGE.SYSTEM);
  var [currentPage,setCurrentPage] = useState(PAGE.LOGIN);

  function changeRootPage(page){
    setCurrentPage(page);
  }

  return(
    <div>
      {currentPage === PAGE.LOGIN && <Login changeRootPage={changeRootPage} />}
      {currentPage === PAGE.REG && <Reg changeRootPage={changeRootPage} />}
      {currentPage === PAGE.SYSTEM && <System changeRootPage={changeRootPage} />}
      {currentPage === PAGE.GAME && <Game changeRootPage={changeRootPage} />}

    </div>
  );

}
export default App;