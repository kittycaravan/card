import React, { useState } from 'react';
import axios from 'axios'; // axios를 별도로 임포트
import './Login.css';
import PAGE from './PAGE.js';
import API from './API.js';

export default function Login({changeRootPage}) {
  var [id, setId] = useState('');
  var [password, setPassword] = useState('');   

  return(
    <div id='loginbox' style={{backgroundImage: 'url(/card/resources/img/bg/login.png)', backgroundSize: 'cover', height: '100vh'}}>
      <form id="loginForm" onSubmit={(e) => {
        e.preventDefault();
        // 로그인 처리 로직 추가
        console.log("로그인 시도");
        // axios 통신. 데이터 키, 값 주의. 
        const d = {
          id: id,
          pw: password
        }
        axios.post(API.LOGIN, d)
        .then(response => {
          if (response.data.success) {
              //window.location.href = PAGE.SYSTEM; // 예시로 시스템 페이지로 이동
              changeRootPage(PAGE.SYSTEM); // 페이지 이동 함수 호출
            } else {
              alert('로그인 실패: ' + response.data.message);
            }
          })
          .catch(error => {
            console.error('로그인 오류:', error);
            alert('로그인 중 오류 발생');
          });
      }}>
        <br></br>
        <input type="text" placeholder="아이디" onChange={(e)=>setId(e.target.value)} />
        <br></br>
        <input type="password" placeholder="비밀번호" onChange={(e)=>setPassword(e.target.value)} />
        <br></br>
        <button type="submit">로그인</button>
        <br></br>
        <button type="button" onClick={() => changeRootPage(PAGE.REG)}>회원가입</button>
        <br></br>
      </form>
    </div>
  );
}