import React, { useState } from 'react';
//todo 이 파일은 미사용?
function GuildAlliance() {
  return(
    <>
      <h1>GuildAlliance</h1>
    </>
  );
}
export default GuildAlliance;