import '../../App.css';
import './Stars.css';
function Stars({amount}) {
  let stars = '';
  for (let i = 0; i < amount; i++) {
    stars += '⭐';
  }  

  return (
    <span id='stars'>
      {stars}
    </span>
  );
}

export default Stars;