import React, { useState } from 'react';
import './Map.css'
function Map() {
  return(
    <div id='game_map_bg' style={{backgroundImage: 'url(/card/resources/img/bg/map_world.webp)'}}>
      <h1>Map</h1>
    </div>
  );
}
export default Map;