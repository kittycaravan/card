import '../../App.css';
import './Card.css';
function Card({ job, grade, xxx}) {
  return (
    <div className={`card ${grade}`} onClick={xxx} style={{backgroundImage: `url(/card/resources/img/cards/${job}.webp)`}}>
      {job} - {grade} {/* job과 grade를 표시 */}
    </div>
  );
}

export default Card;