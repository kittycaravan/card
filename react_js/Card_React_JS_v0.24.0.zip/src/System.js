import PAGE from './PAGE.js';
import React, { useState, useEffect } from 'react';
import './System.css';
import Lobby from './page/system/Lobby.js';
import Cash from './page/system/Cash.js';
import Characters from './page/system/Characters.js';
import Community from './page/system/Community.js';
function System({changeRootPage}) {
  var [currentPage,setCurrentPage] = useState(PAGE.SYSTEM_LOBBY);
  return(
    <>
      {/* 페이지 전환 버튼 */}
      <nav>
        <button onClick={() => setCurrentPage(PAGE.SYSTEM_LOBBY)}>로비</button>
        <button onClick={() => setCurrentPage(PAGE.SYSTEM_CASH)}>캐쉬 상점</button>
        <button onClick={() => setCurrentPage(PAGE.SYSTEM_CHARACTERS)}>케릭터 관리</button>
        <button onClick={() => setCurrentPage(PAGE.SYSTEM_COMMUNITY)}>커뮤니티</button>&nbsp;
        <button onClick={()=>changeRootPage(PAGE.GAME)}>게임시작</button>
      </nav>    
      {currentPage === PAGE.SYSTEM_LOBBY && <Lobby/>}
      {currentPage === PAGE.SYSTEM_CASH && <Cash/>}
      {currentPage === PAGE.SYSTEM_CHARACTERS && <Characters/>}
      {currentPage === PAGE.SYSTEM_COMMUNITY && <Community/>}
    </>
  );
}
export default System;