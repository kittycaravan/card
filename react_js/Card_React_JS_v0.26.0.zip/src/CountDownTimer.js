import React, { useState, useEffect } from 'react';
import { Duration } from 'luxon';   // npm install luxon 설치 필요
import './CountDownTimer.css';

function CountdownTimer({ title, startSec }) {
    const [nowSec, setNowSec] = useState(
        Duration.fromObject({ seconds: startSec })
    );

    useEffect(() => {
        // 타이머 설정
        const interval = setInterval(() => {
            setNowSec((prevTime) => {
                if (prevTime.seconds <= 1) {
                    clearInterval(interval); // 시간이 끝나면 타이머 정지
                    return Duration.fromObject({ seconds: 0 });
                }
                return prevTime.minus({ seconds: 1 });
            });
        }, 1000);

        return () => clearInterval(interval); // 컴포넌트 언마운트 시 클리어
    }, []);

    // 시간을 시:분:초 형식으로 포맷
    const formattedTime = nowSec.toFormat('hh:mm:ss');

    return (
        <span id='count_down_timer'>
            {title}{formattedTime}
        </span>
    );
}

export default CountdownTimer;
